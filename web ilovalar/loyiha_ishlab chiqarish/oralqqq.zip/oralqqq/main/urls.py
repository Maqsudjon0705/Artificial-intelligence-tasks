from django.urls import path
from .views import HomePageViev,CcontactViev,ContactViev, ProductViev, satViev

urlpatterns = [
    path('home', HomePageViev.as_view(), name='home'),
    path('erkaklar', ContactViev.as_view(), name='erkaklar'),
    path('bolalar', ProductViev.as_view(), name='bolalar'),
    path('ayollar', CcontactViev.as_view(), name='ayollar'),
    path('savat', satViev.as_view(), name='savat'),
]