from django.shortcuts import render
from django.views.generic import ListView, TemplateView
from .models import Post
# Create your views here.

class HomePageViev(ListView):
    model = Post
    template_name = "index.html"

class ProductViev(TemplateView):
    template_name = "bolalar.html"

class ContactViev(TemplateView):
    template_name = "erkaklar.html"

class CcontactViev(TemplateView):
    template_name = "ayollar.html"

class satViev(TemplateView):
    template_name = "savat.html"