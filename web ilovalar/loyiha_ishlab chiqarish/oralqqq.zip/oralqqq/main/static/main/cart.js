document.addEventListener('DOMContentLoaded', function() {
  // Savatdagi mahsulotlarni yuklash
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartList = document.getElementById('cart-list');
  const emptyCart = document.getElementById('empty-cart');
  const totalItemsEl = document.getElementById('total-items');
  const totalPriceEl = document.getElementById('total-price');
  const grandTotalEl = document.getElementById('grand-total');
  const checkoutBtn = document.getElementById('checkout-btn');

  // Savatni ko'rsatish
  function displayCart() {
    if (cart.length === 0) {
      emptyCart.style.display = 'block';
      cartList.style.display = 'none';
      document.querySelector('.cart-count').textContent = '0';
    } else {
      emptyCart.style.display = 'none';
      cartList.style.display = 'block';
      document.querySelector('.cart-count').textContent = cart.length;
      
      // Savatdagi mahsulotlarni chiqarish
      cartList.innerHTML = '';
      let totalPrice = 0;
      
      cart.forEach((item, index) => {
        // Narxni son ko'rinishida olish
        const price = parseInt(item.price.replace(/\D/g, ''));
        totalPrice += price * item.quantity;
        
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
          <img src="${item.image}" alt="${item.name}" class="cart-item-image">
          <div class="cart-item-details">
            <div class="cart-item-header">
              <h3 class="cart-item-title">${item.name}</h3>
              <p class="cart-item-price">${item.price}</p>
            </div>
            <p class="cart-item-size">Razmer: ${item.size}</p>
            <div class="cart-item-actions">
              <div class="quantity-control">
                <button class="quantity-btn minus" data-index="${index}">-</button>
                <input type="number" value="${item.quantity}" min="1" class="quantity-input" data-index="${index}">
                <button class="quantity-btn plus" data-index="${index}">+</button>
              </div>
              <button class="remove-item" data-index="${index}">O'chirish</button>
            </div>
          </div>
        `;
        cartList.appendChild(cartItem);
      });
      
      // Jami summalarni hisoblash
      const deliveryFee = 30000;
      totalItemsEl.textContent = `${cart.length} ta`;
      totalPriceEl.textContent = `${totalPrice.toLocaleString()} so'm`;
      grandTotalEl.textContent = `${(totalPrice + deliveryFee).toLocaleString()} so'm`;
    }
  }
  
  // Miqdorni o'zgartirish
  function updateQuantity(index, newQuantity) {
    if (newQuantity < 1) newQuantity = 1;
    cart[index].quantity = newQuantity;
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
  }
  
  // Mahsulotni o'chirish
  function removeItem(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
  }
  
  // Buyurtma berish
  function checkout() {
    if (cart.length === 0) {
      alert('Savat bo\'sh. Iltimos, avval mahsulot qo\'shing.');
      return;
    }
    
    // Bu yerda haqiqiy loyihada to'lov tizimiga yo'naltirish kerak
    alert('Buyurtmangiz qabul qilindi! Tez orada operatorlarimiz siz bilan bog\'lanishadi.');
    localStorage.removeItem('cart');
    displayCart();
  }
  
  // Hodisalarni qo'shish
  cartList.addEventListener('click', function(e) {
    if (e.target.classList.contains('minus')) {
      const index = e.target.dataset.index;
      updateQuantity(index, cart[index].quantity - 1);
    } else if (e.target.classList.contains('plus')) {
      const index = e.target.dataset.index;
      updateQuantity(index, cart[index].quantity + 1);
    } else if (e.target.classList.contains('remove-item')) {
      const index = e.target.dataset.index;
      removeItem(index);
    }
  });
  
  cartList.addEventListener('change', function(e) {
    if (e.target.classList.contains('quantity-input')) {
      const index = e.target.dataset.index;
      updateQuantity(index, parseInt(e.target.value));
    }
  });
  
  checkoutBtn.addEventListener('click', checkout);
  
  // Dastlab savatni ko'rsatish
  displayCart();
});