document.addEventListener('DOMContentLoaded', function() {
  // Savat funksionalligi
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  
  // Mahsulot qo'shish
  const addToCartButtons = document.querySelectorAll('.add-to-cart');
  addToCartButtons.forEach(button => {
    button.addEventListener('click', function() {
      const productCard = this.closest('.product-card');
      const productName = productCard.querySelector('h3').textContent;
      const productPrice = productCard.querySelector('.price').textContent;
      const productSize = productCard.querySelector('.size-select').value;
      const productImage = productCard.querySelector('img').src;
      
      const product = {
        name: productName,
        price: productPrice,
        size: productSize,
        image: productImage,
        quantity: 1
      };
      
      // Tekshirish - agar mahsulot savatda bo'lsa
      const existingProduct = cart.find(item => 
        item.name === product.name && item.size === product.size
      );
      
      if (existingProduct) {
        existingProduct.quantity += 1;
      } else {
        cart.push(product);
      }
      
      localStorage.setItem('cart', JSON.stringify(cart));
      alert('Mahsulot savatga qo\'shildi!');
    });
  });
  
  // Filtrlash funksionalligi
  const filterBtn = document.querySelector('.filter-btn');
  if (filterBtn) {
    filterBtn.addEventListener('click', function() {
      const sizeFilter = document.getElementById('size').value;
      const colorFilter = document.getElementById('color').value;
      
      // Bu yerda haqiqiy loyihada serverdan ma'lumotlarni filtrlash kerak
      // Misol uchun AJAX so'rovi yuborish
      alert(`Filtr qo'llandi: Razmer - ${sizeFilter}, Rang - ${colorFilter}`);
    });
  }
});